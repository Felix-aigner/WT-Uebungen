
<div class="footer col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <footer>
        <ul>
            <li>
                <p>Terms of Use</p>
            </li>
            <li>
                <p>Copyright</p>
            </li>
            <li>
                <p>some random Contact</p>
            </li>
            <li>
                <p>another random Contact</p>
            </li>
        </ul>
    </footer>
</div>