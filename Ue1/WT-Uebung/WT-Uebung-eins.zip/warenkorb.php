

<div class="info">
    <main>
        
            <h2>Warenkorb</h2>
            <div class="under-const">
                <img src="res/under-construction.jpg" alt="under-const">
            </div>
            <div class="home-text">
                <p>no sea takimata sanctus est Lorem ipsum dolor sit amet.   
                Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, 
                vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan 
                et iusto odio dignissim qui blandit praesent luptatum zzril 
                delenit augue duis dolore te feugait nulla facilisi. Lorem ipsum dolor sit amet,</p>    
            </div>
        
    </main>
    <?php include("footer.php")?>
</div>