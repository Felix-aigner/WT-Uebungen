

<div class="info">
    <main>
        <h2>Produkte</h2>
        <img src="res/Produkte-Banner.jpg" alt="Banner"/>
        <div class="home-text">
            <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, 
            sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. 
            At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, 
            no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>    
        </div>
        <div class="products">
            <div class="produkt col-xl-3 col-md-3 col-sm-4 col-xs-6">
                <img src="res/cage-candle.jpg" alt="cage"/>
                <p>Nicolas Candle</p>
            </div>
            <div class="produkt col-xl-3 col-md-3 col-sm-4 col-xs-6">
                <img src="res/cage-cover.jpg" alt="cage"/>
                <p>Nicolas Case (all devices)</p>
            </div>
            <div class="produkt col-xl-3 col-md-3 col-sm-4 col-xs-6">
                <img src="res/cage-mug.jpg" alt="cage"/>
                <p>Nicolas Cup</p>
            </div>
            <div class="produkt col-xl-3 col-md-3 col-sm-4 col-xs-6">
                <img src="res/cage-shirt.jpg" alt="cage"/>
                <p>Nicolas Shirt</p>
            </div>
            <div class="produkt col-xl-3 col-md-3 col-sm-4 col-xs-6">
                <img src="res/cagenstein.jpg" alt="cage"/>
                <p>Mausepad Cagenstein</p>
            </div>
            <div class="produkt col-xl-3 col-md-3 col-sm-4 col-xs-6">
                <img src="res/cage-pillow.jpg" alt="cage"/>
                <p>Nicolas Pillow</p>
            </div>
        </div>
        
        
    </main>
    </div>
    <?php include("footer.php"); ?>
