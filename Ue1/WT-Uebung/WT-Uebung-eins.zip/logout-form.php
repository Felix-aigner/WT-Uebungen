




<nav>
    <div class="menu">
        <ul>
            <li><a href="index.php?section=Home">Home</a></li>
            <li><a href="index.php?section=Produkte">Produkte</a></li>
            <li><a href="index.php?section=Warenkorb">Warenkorb</a></li>
        </ul>
    </div>
    <div class="logout-form">
        <h3>Sign out</h3>
        <form action="logout.php">
            <fieldset>
                    <input type="submit" value="Logout"/>
            </fieldset>
        </form>
    </div>  
</nav>
